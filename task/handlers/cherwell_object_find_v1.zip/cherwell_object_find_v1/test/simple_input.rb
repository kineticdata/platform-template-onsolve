{
  'info' => {
    'api_location' => '',
    'client_id' => '',
    'client_secret' => '',
    'username' => '',
    'password' => '',
    'enable_debug_logging'=>'yes'
  },
  'parameters' => {
    'error_handling' => 'Error Message',
    'object_name' => 'Incident',
    'fields' => 'Status,Description,Short Description',
    'filters' => '{"Incident ID": "102384"}',
    'page_size' => '2'
  }
}
