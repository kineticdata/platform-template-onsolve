# Require the dependencies file to load the vendor libraries
require File.expand_path(File.join(File.dirname(__FILE__), "dependencies"))

class IvantiGenericApiV1
  # ==== Parameters
  # * +input+ - The String of Xml that was built by evaluating the node.xml handler template.
  def initialize(input)
    # Set the input document attribute
    @input_document = REXML::Document.new(input)

    # Retrieve all of the handler info values and store them in a hash variable named @info_values.
    @info_values = {}
    REXML::XPath.each(@input_document, "/handler/infos/info") do |item|
      @info_values[item.attributes["name"]] = item.text.to_s.strip
    end

    # Retrieve all of the handler parameters and store them in a hash variable named @parameters.
    @parameters = {}
    REXML::XPath.each(@input_document, "/handler/parameters/parameter") do |item|
      @parameters[item.attributes["name"]] = item.text.to_s.strip
    end

    @debug_logging_enabled = ["yes","true"].include?(@info_values['enable_debug_logging'].downcase)
    @error_handling = @parameters["error_handling"]

    @api_location = @info_values["api_location"]
    @api_location.chomp!("/")
    @api_username = @info_values["username"]
    @api_password = @info_values["password"]

    @body = @parameters["body"].to_s.empty? ? {} : JSON.parse(@parameters["body"])
    @method = (@parameters["method"] || :get).downcase.to_sym
    @path = @parameters["path"]
    @path = "/#{@path}" if !@path.start_with?("/")

    @accept = :json
    @content_type = :json
  end

  def execute
    if REXML::Security.entity_expansion_text_limit < 163840
      puts "Setting 'Entity Expansion Limit' to 163840" if @enable_debug_logging
      REXML::Security.entity_expansion_text_limit=(163840)
    end

    # Initialize return data
    error_message = nil
    response_code = nil
begin

	#remove http to get the tenant name
	tenant = @info_values['api_location'].downcase.gsub("https://","").gsub("http://","")



# Retrieve an access token from Ivanti

# this call will return the token wraped in html for example: puts httpresp or puts httpresp.body will return
#  <string xmlns="http://schemas.microsoft.com/2003/10/Serialization/">adventist-stg.saasit.com#5T159LKAV0I9R8M7NO3GT145HAREEMTQ#2</string>	
#	httpresp = RestClient.post(
#        @info_values['api_location']+"/api/rest/authentication/login",
#        {
#          "tenant" => tenant,
#          "username" => @info_values['username'],
#          "password" => @info_values['password'],
#		  "role" => @info_values['role']
#        }
#      )
	
	
#This call will return a string that contains quotes for example: 
	idresource = RestClient::Resource.new(@info_values['api_location']+"/api/rest/authentication/login", {:headers =>
        {
          :content_type => "application/json",
          :accept => "application/json"
        }
      })
	resp = idresource.post({
          "tenant" => tenant,
          "username" => @info_values['username'],
          "password" => @info_values['password'],
		  "role" => @info_values['role']
        })
	
puts "Raw ivanti_generic_api_v1 login body = " + resp.body if @debug_logging_enabled
#sessionid = resp.body.gsub('"',"")
#Remove the quotes from the return body
sessionid = resp[1..resp.body.length-2]
puts "ivanti_generic_api_v1 Session ID = " + sessionid if @debug_logging_enabled







# this is the mail call to either get the data or update, delete data


	resource = RestClient::Resource.new(@info_values['api_location']+"/api/odata/businessobject/", {:headers =>
        {
		  :content_type => "application/json",
		  :authorization => sessionid,
		  :accept => "application/json"
        }
      })
#	resp = getbusinessobject.get()
# this seems to always be json
# puts "Raw ivanti_generic_api_v1 businessobject = " + resp if @debug_logging_enabled
#puts "ivanti_generic_api_v1 body businessobject body = " + resp.body if @debug_logging_enabled




#      resource = RestClient::Resource.new(@info_values['api_location'], {:headers =>
#        {
#          :authorization => "Bearer #{JSON.parse(resp.body)["access_token"]}",
#          :content_type => "application/json",
#          :accept => "application/json"
#        }
#      })
#
      api_route = "#{@api_location}/api/odata/businessobject#{@path}"
      puts "API ROUTE: #{@method.to_s.upcase} #{api_route}" if @debug_logging_enabled
      puts "BODY: \n #{@body}" if @debug_logging_enabled
#
      resp = case @method
      when :get
        resource[@path].get
      when :post
        resource[@path].post(@body.to_json)
      when :put
        resource[@path].put(@body.to_json)
      when :delete
        resource[@path].delete
      else
        error_message = "No method or invalid method specified"
        raise "No method or invalid method specified" if @error_handling == "Raise Error"
      end

      response_code = resp.code

#for a get (search) if there are no results then nothing is returned
if (!resp.empty?)
  


  case @method
      when :get
          resp = JSON.parse(resp)
          puts resp['value'].to_json
          resp = resp['value'].to_json
      when :post
          resp = JSON.parse(resp)
      when :put
	      resp = JSON.parse(resp)
      when :delete
          resp = JSON.parse(resp)
      end












  
end




















#logout the resp is diferent because this should not error if the login and the get, post... calls are sucessful.  The handler will retrun the body of the last resp.
    logoutresp = RestClient::Request.execute(:method => 'delete', :url => @info_values['api_location']+"/api/rest/authentication/logout", :headers => {:authorization => sessionid}, :payload => {"tenant" => tenant})

# this call will return a 500 error from the server
#	logoutresp = RestClient::Resource.new(@info_values['api_location']+"/api/rest/authentication/logout", {:headers =>
#        {
#		  :authorization => sessionid
#        }
#      })
#	logoutresp = logoutresp.delete({
#          "tenant" => tenant
#        })

# puts "Raw ivanti_generic_api_v1 logout = " + logoutresp if @debug_logging_enabled
puts "ivanti_generic_api_v1 body businessobject = " + logoutresp.body if @debug_logging_enabled

 
      








    rescue RestClient::ResourceNotFound => error
      error_message = error.inspect
      response_code = error.response ? error.response.code : nil
      raise "404 Not Found: Make sure the 'api_location' and 'path' are valid inputs:\n#{error.http_body}." if @error_handling == "Raise Error"
    rescue RestClient::ExceptionWithResponse => error
      begin
        error_message = error.response
      rescue
        error_message = error.inspect
      end
      raise error if @error_handling == "Raise Error"
    rescue RestClient::Exception => error
      error_message = error.inspect
      response_code = error.response ? error.response.code : nil
      raise error if @error_handling == "Raise Error"
    rescue Exception => error
      error_message = error.inspect
      raise error if @error_handling == "Raise Error"
    end

    # Return (and escape) the results that were defined in the node.xml
    <<-RESULTS
    <results>
      <result name="Response Body">#{escape(resp.nil? ? {} : resp)}</result>
      <result name="Response Code">#{escape(response_code)}</result>
      <result name="Handler Error Message">#{escape(error_message)}</result>
    </results>
    RESULTS
  end

  ##############################################################################
  # General handler utility functions
  ##############################################################################

  # This is a template method that is used to escape results values (returned in
  # execute) that would cause the XML to be invalid.  This method is not
  # necessary if values do not contain character that have special meaning in
  # XML (&, ", <, and >), however it is a good practice to use it for all return
  # variable results in case the value could include one of those characters in
  # the future.  This method can be copied and reused between handlers.
  def escape(string)
    # Globally replace characters based on the ESCAPE_CHARACTERS constant
    string.to_s.gsub(/[&"><]/) { |special| ESCAPE_CHARACTERS[special] } if string
  end
  # This is a ruby constant that is used by the escape method
  ESCAPE_CHARACTERS = {'&'=>'&amp;', '>'=>'&gt;', '<'=>'&lt;', '"' => '&quot;'}
end
