{
  'info' => {
    'api_location' => '',
    'username' => '',
    'password' => '',
	'role' => '',
    'enable_debug_logging'=>'yes'
  },
  'parameters' => {
    'error_handling' => 'Error Message',

    #2 search examples
	#'method' => 'GET',
	#'path' => "AHPagings?$filter=PageStatus eq 'Cancelled' and PageType eq 'FirstResponse'",
	#'path' => "incidents?$filter=Status eq 'Active'",
	#'body' => ''
	
	#1 update example with body
	#'method' => 'PUT',
	#'path' => "AHPagings('4CD0F00CB8A94442AF193D2A5482F239')",
	#'body' => '{"PageDetails":"Testing PROD"}'
	
	#get user information
	'method' => 'GET',
	'path' => "employees?$filter=LoginID eq 'mir3admin'",
	'body' => ''
  }
}


# Find-a-Responder Callout 
# ?$filter=PageStatus eq 'Initiated' and PageType eq 'FirstResponse'",
# what details?  Callout message will be constructed using details from the AHPaging form
# would this be the PageTeam?
# Fields found on the pageing form:
# RecId: "150D4B321B3546B589699D6C7974E125",
# CreatedBy: "RampasFN",
# CreatedDateTime: "2020-04-01T12:18:23Z",
# LastModBy: "INPS",
# LastModDateTime: "2020-04-01T12:20:50Z",
# ReadOnly: false,
# AcknowledgedBy: "perezn1",
# AcknowledgedOn: "2020-04-01T12:20:17Z",
# CustomerLocation: "AHGL",
# CustomerName: "Steven Bailon",
# CustomerPhone: "+1-818-409-8260",
# INSchedule: "GAMC_TECH",
# PagedOn: "2020-04-01T12:18:32Z",
# PagedBy: "RampasFN",
# PageDetails: "CPU is locked",
# PageLinkTeam_Category: null,
# PageLinkTeam_RecID: null,
# PageLinkTeam: null,
# PageNumber: 126477,
# PageOnCallHours: "On Call 24x7",
# PagePriority: "3",
# PageStatus_Valid: "75F41A7498F84831BEFDEEFEFA5B00DA",
# PageStatus: "Notified",
# PageSummary: "+1-818-409-8260-Heart monitor is showing up a blank screen. Affecting patient care.",
# PageTeam_Valid: "2D1EAF5A372B4EB4AF3472AE6922E9B1",
# PageTeam: "AHGL_TECH",
# PageTeamManager: "Marc See",
# PageType_Valid: "83BECB664B954B53A08D12B4E7BDACDA",
# PageType: "FirstResponse",
# ParentLinkPage_Category: "Incident",
# ParentLinkPage_RecID: null,
# ParentLinkPage: null,
# ParentObjectDisplayID: "632271",
# Status_Valid: "BBFA0BF9036347EA8198FC83A7437F21",
# Status: "Completed",
# SCPageInfo: "Paged AHGL_TECH on P3 Incident#632271, Page#126477 for subject: +1-818-409-8260-Heart monitor is showing up a blank screen. Affecting patient care.",
# IsPaged: true,
# IsActive: false,
# IsAcknowledged: false,
# PageRespInMins: 1,
# ParentLink_Category: "Incident",
# ParentLink_RecID: "00549083D48244DD9812A97CD1E4FC3B",
# ParentLink: null





#Filter examples

#?$filter=LoginID eq 'mir3admin'


#?$filter=CreatedDateTime gt 2020-04-01T07:22:00Z and CreatedDateTime lt 2020-04-02T07:22:00Z

#?$filter=owner eq '$NULL'

#?$filter=PageStatus eq 'Cancelled' and PageType eq 'FirstResponse'",

#All dates in ISD are stored in UTC. This allows us to filter on dates by filtering on dates entered in the Universal date/time pattern.
#?$filter=CreatedDateTime gt 2020-04-01T07:22:00Z

#Delete:
#https://{tenant url}/api/odata/businessobject/incidents('0464AABB3FCF4EBC993D4CDC7C3EE8F4')

#Get: (by Filter)
#https://{tenant url}/api/odata/businessobject/incidents?$filter=Status eq 'Active'
#$filter=Price le 200 and Price gt 3.5
#$filter=not endswith(Description,'milk')


#(sort order by) ?orderby=IncidentNumber asc
#(select fields to return) ?$select=RecId, StartDateTime
#(generic search) ?$search=Boardroom

#Put: (Update)
#https://{tenant url}/api/odata/businessobject/changes('02818A8426C9402E8DFE7C8D3132F783')

#Post: (Create)
#https://{tenant url}/api/odata/businessobject/changes
#Payload:
#{
#"Category: "Computer",
#"CreatedBy":"Admin",
#"RequestorLink_RecID":"FB884D18F7B746A0992880F2DFFE749C",
#"Description" : "test",
#"Owner: "BHeath",
#"OwnerTeam":"Accounting",
#"Subject":"test",
#"OwnerTeam_Valid":"8D796372096546AC9008C0EDAB18EE5F",
#"Owner_Valid":"147098AD139247F6B177042064C5E39C",
#"Status":"Logged",
#"TypeOfChange: "Minor"
#}



#https://tatnet.ivanti.com/api/odata/businessobject

#{
#  'info' => {
#    'api_location' => 'http://cherwell.kineticdata.com/CherwellAPI',
#    'client_id' => '7a13da8a-6600-4274-a0a0-817313e2c65e',
#    'client_secret' => '',
#    'username' => 'Mark.Klein@KineticData.com',
#    'password' => 'Y@8j$@5Pe3ol',
#    'auth_mode' => 'Internal',
#    'enable_debug_logging'=>'yes'
#  },
#  'parameters' => {
#    'error_handling' => 'Error Message',
#    'object_name' => 'Incident',
#    'object_id' => '102408'
#  }
#}

