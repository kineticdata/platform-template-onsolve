{
  'info' =>
  {
    'username'=>'',
    'password'=>'',
    'server'=>'',
    'enable_debug_logging'=>'yes'
  },
  'parameters' =>
  {
    'table' => 'incident',
    'id'=> 'ea45634c4f5103004491b3728110c7ac',
    'json_body'=> '{"short_description": "A different description"}'
  }
}
