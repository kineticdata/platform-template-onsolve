{
  'info' => {
    'api_location' => '',
    'client_id' => '',
    'client_secret' => '',
    'username' => '',
    'password' => '',
    'auth_mode' => '',
    'enable_debug_logging'=>'yes'
  },
  'parameters' => {
    'error_handling' => 'Error Message',
    'object_name' => 'Incident',
    'object_id' => '',
    'object_json' => ''
  }
}
