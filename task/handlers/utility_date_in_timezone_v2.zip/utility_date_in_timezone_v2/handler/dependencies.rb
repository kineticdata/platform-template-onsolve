# If the Kinetic Task version is under 4, load the json libraries
# because they are not included in the ruby version
if KineticTask::VERSION.split(".").first.to_i < 4
  # Load the ruby json library unless
  # it has already been loaded.  This prevents multiple handlers using the same
  # library from causing problems.
  if not defined?(JSON)
    # Calculate the location of this file
    handler_path = File.expand_path(File.dirname(__FILE__))
    # Calculate the location of our library and add it to the Ruby load path
    library_path = File.join(handler_path, "vendor/json-1.8.0/lib")
    $:.unshift library_path
    # Require the library
    require "json"
  end

  # Validate the the loaded JSON library is the library that is expected for
  # this handler to execute properly.
  if not defined?(JSON::VERSION)
    raise "The JSON class does not define the expected VERSION constant."
  elsif JSON::VERSION.to_s != "1.8.0"
    raise "Incompatible library version #{JSON::VERSION} for JSON.  Expecting version 1.8.0."
  end
end

if not defined?(Concurrent)
  # Calculate the location of this file
  handler_path = File.expand_path(File.dirname(__FILE__))
  # Load the Concurrent library unless it has already been loaded.
  # This library is required by the tzinfo library.
  $:.unshift File.join(handler_path, "vendor", "concurrent-ruby-1.0.5-java", "lib")
  # Require the library
  require "concurrent"
end

# Load the tzinfo library unless it has already been loaded.
# This prevents multiple handlers using the same library from causing problems.
if not defined?(TZInfo)
  # Calculate the location of this file
  handler_path = File.expand_path(File.dirname(__FILE__))
  # Calculate the location of our library and add it to the Ruby load path
  $:.unshift File.join(handler_path, "vendor", "tzinfo-2.0.0-pre1", "lib")
  $:.unshift File.join(handler_path, "vendor", "tzinfo-data-1.2018.5", "lib")
  # Require the libraries
  require "tzinfo"
  require "tzinfo/data"
end

# Validate the the loaded JSON library is the library that is expected for
# this handler to execute properly.
if not defined?(TZInfo::VERSION)
  raise "The TZInfo class does not define the expected VERSION constant."
elsif TZInfo::VERSION.to_s != "2.0.0.pre1"
  raise "Incompatible library version #{TZInfo::VERSION} for TZInfo.  Expecting version 2.0.0.pre1"
end
