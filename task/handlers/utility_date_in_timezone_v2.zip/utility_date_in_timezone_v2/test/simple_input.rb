#{
#  'info' => {
#    'enable_debug_logging'=>'yes'
#  },
#  'parameters' => {
#    'timezone' => 'America/Chicago',
#    'timestamp' => '2019-01-16T22:45:00Z',
#    'direction' => 'To UTC'
#  }
#}

## DST Test
#{
#  'info' => {
#    'enable_debug_logging'=>'yes'
#  },
#  'parameters' => {
#    'timezone' => 'America/New_York',
#    'timestamp' => '2020-11-01T01:18:00Z',
#    'direction' => 'To Local'
#  }
#}


## DST Test 2
{
  'info' => {
    'enable_debug_logging'=>'yes'
  },
  'parameters' => {
    'timezone' => 'America/New_York',
    'timestamp' => '2021-03-14T02:30:00Z',
    'direction' => 'To Local'
  }
}
