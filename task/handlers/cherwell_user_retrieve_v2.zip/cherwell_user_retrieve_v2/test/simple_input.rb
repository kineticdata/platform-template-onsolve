{
  'info' => {
    'api_location' => '',
    'client_id' => '',
    'client_secret' => '',
    'username' => '',
    'password' => '',
    'enable_debug_logging'=>'yes'
  },
  'parameters' => {
    'login_id' => ''
    'login_id_type' => 'Internalx'
  }
}
