{
  'info' => {
    'server' => '',
	'port' => '',
    'username' => '',
    'password' => '',
    'enable_debug_logging' => 'Yes'
  },
  'parameters' => {
    'jdbc_database' => 'sqlserver',
	'dbname' => 'MKTest',
    'query'  => 'SELECT TOP(100) * FROM MKTest.dbo.test',
	'action'  => 'fetch',
	
    #'query'  => "UPDATE MKTest.dbo.test SET [First Name] = 'asdf' WHERE [Last Name] = 'Klein'",
	#'action'  => 'run',
    
	'error_handling' => 'Raise Error'
  }
}