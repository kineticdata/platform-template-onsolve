# Ensure that the JRuby java library is loaded
require 'java'
require File.expand_path(File.join(File.dirname(__FILE__), 'dependencies'))

#this is to test the server and port number
require 'socket'

class SqlGenericV1
  # Initializes the handler and set the following instance variables:
  # * @input_document - A REXML::Document object that represents the input Xml.
  # * @configuration  - A Hash of handler configuration information.
  # * @info_values    - A Hash of info value names to values.
  # * @parameters     - A Hash of parameter names to parameter values.
  #
  # This is a required method that is automatically called by the Kinetic Task
  # Engine.
  #
  # ==== Parameters
  # * +input+ - The String of Xml that was built by evaluating the node.xml
  #   handler template.
  def initialize(input)
    # It may make sense to parameterize this value.
    # For some returned queries the volume of data generated an error message when
    # this is set to the default value of 10240.  Future releases of Kinetic Platform
    # may adjust this setting.  Here we're checking if it is currently less than an
    # arbitrarily higher value.  This setting is globally applicable within Task.
    if REXML::Security.entity_expansion_text_limit < 163840
      puts "Setting 'Entity Expansion Limit' to 163840" if @enable_debug_logging
      REXML::Security.entity_expansion_text_limit=(163840)
    end

    # Set the input document attribute
    @input_document = REXML::Document.new(input)

    # Retrieve all of the handler info values and store them in a hash attribute
    # named @info_values.
    @info_values = {}
    REXML::XPath.match(@input_document, '/handler/infos/info').each do |node|
      @info_values[node.attribute('name').value] = node.text
    end

    # Retrieve all of the handler configuration and store them in a hash attribute
    # named @configuration.
    @configuration = {}
    REXML::XPath.match(@input_document, '/handler/configuration/config').each do |node|
      @configuration[node.attribute('name').value] = node.text
    end

	# Retrieve all of the handler parameters and store them in a hash variable named @parameters.
    @parameters = {}
    REXML::XPath.each(@input_document, "/handler/parameters/parameter") do |item|
      @parameters[item.attributes["name"]] = item.text.to_s.strip
    end

    @enable_debug_logging = @info_values['enable_debug_logging'] == 'Yes'

  end

  # Executes the specified SQL query.
  #
  # This is a required method that is automatically called by the Kinetic Task
  # Engine.
  #
  # ==== Returns
  # An Xml formatted String representing the return variable results.
  def execute

	error_message = nil
    #checking to see if the server and port are open
    #this was put in to test java vm access to my local sql server
    begin
      socket = TCPSocket.new(@info_values['server'], @info_values['port'])
      puts "Port #{@info_values['port']} at server '#{@info_values['server']}' is open." if @enable_debug_logging
      begin
	    if @parameters["jdbc_database"].downcase == "sqlserver"
          @db = Sequel.connect("jdbc:#{@parameters["jdbc_database"]}://#{@info_values["server"]}:#{@info_values["port"]};database=#{@parameters["dbname"]};user=#{@info_values["username"]};password=#{@info_values["password"]}")
          @db.extension :identifier_mangling
          @db.identifier_input_method = nil
          @db.identifier_output_method = nil
          @max_db_identifier_size = 128
		elsif @parameters["jdbc_database"].downcase == "oracle"
		  Sequel.database_timezone = :utc
          #Sequel.application_timezone = :utc
          @db = Sequel.connect("jdbc:#{@parameters["jdbc_database"]}:thin:#{@info_values["username"]}/#{@info_values["password"]}@#{@info_values["server"]}:#{@info_values["port"]}:#{@parameters["dbname"]}")
          @db.extension :identifier_mangling
          @db.identifier_input_method = nil
          @db.identifier_output_method = nil
          @max_db_identifier_size = 30
		elsif @parameters["jdbc_database"].downcase == "postgresql"
		  @max_db_identifier_size = 64
          @db = Sequel.connect("jdbc:#{@parameters["jdbc_database"]}://#{@info_values["server"]}:#{@info_values["port"]}/#{@parameters["dbname"]}?user=#{@info_values["username"]}&password=#{@info_values["password"]}")
        elsif @parameters["jdbc_database"].downcase == "mysql"

		end
		if @parameters['action'] == "fetch"
		  record_set = @db.fetch(@parameters['query']).all
		  json_result = JSON(record_set)
		  puts("JSON Result: #{json_result}") if @enable_debug_logging
		else
		  @db.run(@parameters['query'])
		  json_result = "Successful"
		end
	  rescue Exception => e
	    if @parameters['error_handling']=="Raise Error"
		  raise e
		else
	      error_message = e
		end
      ensure
	    if @db
          puts "Closing the JDBC connections that were opened" if @enable_debug_logging
          @db.disconnect
		end
      end
    puts("Handler Error Message: #{error_message}") if @enable_debug_logging
    rescue Errno::ECONNREFUSED, Errno::ETIMEDOUT
      puts "Port #{@info_values['port']} at server '#{@info_values['server']}' is CLOSED or not accessible." if @enable_debug_logging
	  if @parameters['error_handling']=="Raise Error"
	    raise "Port #{@info_values['port']} at server '#{@info_values['server']}' is CLOSED or is not accessible."
	  else
	    error_message = "Port #{@info_values['port']} at server '#{@info_values['server']}' is CLOSED or is not accessible."
	  end


	  ensure
	    if socket
          puts "Closing the socket connection." if @enable_debug_logging
          socket.close
	    end

    end
  	# Return the results as a JSON string
  	<<-RESULTS
    <results>
      <result name="Result">#{escape(json_result)}</result>
      <result name="Handler Error Message">#{escape(error_message)}</result>
    </results>
    RESULTS
  end

  ##############################################################################
  # General handler utility functions
  ##############################################################################

  # This is a template method that is used to escape results values (returned in
  # execute) that would cause the XML to be invalid.  This method is not
  # necessary if values do not contain character that have special meaning in
  # XML (&, ", <, and >), however it is a good practice to use it for all return
  # variable results in case the value could include one of those characters in
  # the future.  This method can be copied and reused between handlers.
  def escape(string)
    # Globally replace characters based on the ESCAPE_CHARACTERS constant
    string.to_s.gsub(/[&"><]/) { |special| ESCAPE_CHARACTERS[special] } if string
  end
  # This is a ruby constant that is used by the escape method
  ESCAPE_CHARACTERS = {'&'=>'&amp;', '>'=>'&gt;', '<'=>'&lt;', '"' => '&quot;'}
  def get_info_value(document, name)
    # Retrieve the XML node representing the desired info value
    info_element = REXML::XPath.first(document, "/handler/infos/info[@name='#{name}']")
    # If the desired element is nil, return nil; otherwise return the text value of the element
    info_element.nil? ? nil : info_element.text
  end
end
