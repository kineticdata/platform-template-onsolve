{
  'info' => {
    'server' => '',
    'username' => '',
    'password' => '',
    'port' => '',
    'prognum' => '0',
    'authentication' => '',
    'enable_debug_logging' => 'No'
  },
  'parameters' => {
	'form' => 'SIT:Site Alias Company LookUp',
    'request_query' => %|'Site' = "Site 1"|
  }
}
#AG005056960001891vUgbimcBQ23YC
#'Change Request Status' != "Closed" AND 'Change Request Status' != "Completed" AND 'Change Request Status' != "Cancelled" AND 'Change Request Status' != "Rejected"