{
  'info' => {
    'server' => '',
    'username' => '',
    'password' => '',
    'port' => '',
    'prognum' => '',
    'authentication' => '',
    'enable_debug_logging' => 'Yes'
  },
  'parameters' => {
    'error_handling' => 'Error Message',
	  'form' => 'SIT:Site Alias Company LookUp',
    'request_query' => %|'Site' = "Site 1"|
  }
}
