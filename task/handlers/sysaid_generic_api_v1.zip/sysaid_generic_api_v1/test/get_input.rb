{
  'info' => {
    'api_location' => '',
    'username' => '',
    'password' => '',
    'enable_debug_logging'=>'yes'
  },
  'parameters' => {
    'error_handling' => 'Error Message',
	'method' => 'GET',
	'path' => "sr/1",
	'body' => ''

    ## Query for sr
    ## 'method' => 'GET',
	## 'path' => "/sr?status=1&fields=status,urgency&limit=2",
    ## status=New does not work
	## 'path' => "/sr?request_user_name=1&limit=22&fields=request_user_name,status,urgency",

	## Sample kinops query for poller
	## update_time={{Start Date}},{{End Date}}
	
	## Update an incident
    ## 'method' => 'PUT',	
	## 'path' => "/sr/1",
	## 'body' => '{"id":"1","info":[{"key":"status","value":"1"}]}'

    ## Add a note
	## 'method' => 'PUT',	
	## 'path' => "/sr/1",
	## 'body' => '{"id":"1","info":[{"key":"notes","value":[{"userName":"admin","createDate":1391756438000,"text":"Now is the Time..."}]}]}'
	
	## 'method' => 'DELETE',
	## 'path' => "sr/ids=10",

  }
}

## Sample results
## [
##     {
## 		"id": "1",
## 		"canUpdate": true,
## 		"canDelete": true,
## 		"canArchive": true,
## 		"hasChildren": false,
## 		"info": [
## 			{
## 				"key": "third_level_category",
## 				"value": "How to?",
## 				"valueClass": "",
## 				"keyCaption": "Third Level Category",
## 				"valueCaption": "How to?"
## 			},
## 			{
## 				"key": "cust_list1",
## 				"value": 0,
## 				"valueClass": "",
## 				"keyCaption": "SR Custom List 1",
## 				"valueCaption": ""
## 			},
## 			{
## 				"key": "max_support_level",
## 				"value": 0,
## 				"valueClass": "",
## 				"keyCaption": "Max Support Level",
## 				"valueCaption": "0"
## 			},
## 			{
## 				"key": "lock_field",
## 				"value": 1,
## 				"valueClass": "",
## 				"keyCaption": "=== Hide/Show Divider ===",
## 				"valueCaption": "1"
## 			},
## 			{
## 				"key": "source",
## 				"value": 0,
## 				"valueClass": "",
## 				"keyCaption": "Source",
## 				"valueCaption": "Administrator - Other"
## 			},
## 			{
## 				"key": "resolution",
## 				"value": "",
## 				"valueClass": "",
## 				"keyCaption": "Resolution",
## 				"valueCaption": ""
## 			},
## 			{
## 				"key": "cust_list2",
## 				"value": 0,
## 				"valueClass": "",
## 				"keyCaption": "SR Custom List 2",
## 				"valueCaption": ""
## 			},
## 			{
## 				"key": "parent_link",
## 				"value": 0,
## 				"valueClass": "",
## 				"keyCaption": "Parent ID",
## 				"valueCaption": ""
## 			},
## 			{
## 				"key": "solution",
## 				"value": "",
## 				"valueClass": "",
## 				"keyCaption": "Solution",
## 				"valueCaption": ""
## 			},
## 			{
## 				"key": "user_manager_name",
## 				"value": null,
## 				"valueClass": "",
## 				"keyCaption": "Request User Manager",
## 				"valueCaption": ""
## 			},
## 			{
## 				"key": "survey_status",
## 				"value": 0,
## 				"valueClass": "",
## 				"keyCaption": "Survey Status",
## 				"valueCaption": "The survey has not been sent."
## 			},
## 			{
## 				"key": "sr_weight",
## 				"value": 0,
## 				"valueClass": "",
## 				"keyCaption": "Weight",
## 				"valueCaption": "0"
## 			},
## 			{
## 				"key": "followup_planned_date",
## 				"value": null,
## 				"valueClass": "",
## 				"keyCaption": "Followup Planned Date",
## 				"valueCaption": ""
## 			},
## 			{
## 				"key": "submit_user",
## 				"value": 1,
## 				"valueClass": "",
## 				"keyCaption": "Submit user",
## 				"valueCaption": "admin"
## 			},
## 			{
## 				"key": "cust_int2",
## 				"value": 0,
## 				"valueClass": "",
## 				"keyCaption": "SR Custom Int 2",
## 				"valueCaption": "0"
## 			},
## 			{
## 				"key": "cust_date1",
## 				"value": null,
## 				"valueClass": "",
## 				"keyCaption": "SR Custom Date 1",
## 				"valueCaption": ""
## 			},
## 			{
## 				"key": "cust_int1",
## 				"value": 0,
## 				"valueClass": "",
## 				"keyCaption": "SR Custom Int 1",
## 				"valueCaption": "0"
## 			},
## 			{
## 				"key": "totalTime",
## 				"value": 1,
## 				"valueClass": "",
## 				"keyCaption": "Total Activities time",
## 				"valueCaption": "1"
## 			},
## 			{
## 				"key": "impact",
## 				"value": 4,
## 				"valueClass": "",
## 				"keyCaption": "Impact",
## 				"valueCaption": "Low"
## 			},
## 			{
## 				"key": "reopen_counter",
## 				"value": 0,
## 				"valueClass": "",
## 				"keyCaption": "Reopen Counter",
## 				"valueCaption": "0"
## 			},
## 			{
## 				"key": "cust_date2",
## 				"value": null,
## 				"valueClass": "",
## 				"keyCaption": "SR Custom Date 2",
## 				"valueCaption": ""
## 			},
## 			{
## 				"key": "archive",
## 				"value": 0,
## 				"valueClass": "",
## 				"keyCaption": "Archive",
## 				"valueCaption": "No"
## 			},
## 			{
## 				"key": "close_time",
## 				"value": null,
## 				"valueClass": "",
## 				"keyCaption": "Close time",
## 				"valueCaption": ""
## 			},
## 			{
## 				"key": "priority",
## 				"value": 4,
## 				"valueClass": "",
## 				"keyCaption": "Priority",
## 				"valueCaption": "Normal"
## 			},
## 			{
## 				"key": "merged_service_records",
## 				"value": null,
## 				"valueClass": "",
## 				"keyCaption": "Merged service records",
## 				"valueCaption": ""
## 			},
## 			{
## 				"key": "version",
## 				"value": 1,
## 				"valueClass": "",
## 				"keyCaption": "Version",
## 				"valueCaption": "1"
## 			},
## 			{
## 				"key": "is_escalated",
## 				"value": 0,
## 				"valueClass": "",
## 				"keyCaption": "Is Escalated",
## 				"valueCaption": "No"
## 			},
## 			{
## 				"key": "closure_information",
## 				"value": 0,
## 				"valueClass": "",
## 				"keyCaption": "Closure Information",
## 				"valueCaption": ""
## 			},
## 			{
## 				"key": "assign_counter",
## 				"value": 1,
## 				"valueClass": "",
## 				"keyCaption": "Assigned Counter",
## 				"valueCaption": "1"
## 			},
## 			{
## 				"key": "problem_type",
## 				"value": "Basic Software",
## 				"valueClass": "",
## 				"keyCaption": "Category",
## 				"valueCaption": "Basic Software"
## 			},
## 			{
## 				"key": "alertID",
## 				"value": 1,
## 				"valueClass": "",
## 				"keyCaption": "Alert",
## 				"valueCaption": "green"
## 			},
## 			{
## 				"key": "status",
## 				"value": 1,
## 				"valueClass": 0,
## 				"keyCaption": "Status",
## 				"valueCaption": "New"
## 			},
## 			{
## 				"key": "problem_sub_type",
## 				"value": "Other",
## 				"valueClass": "",
## 				"keyCaption": "Sub-Category",
## 				"valueCaption": "Other"
## 			},
## 			{
## 				"key": "description",
## 				"value": "This is your first service record in your Service Desk list.\\nNow you can get started with everything SysAid has to offer!\\n\\nFor every page in SysAid, you can access instructions and help relevant for that page.\\nTo access the online help, click your profile name on the top-right corner of the screen and select Online Aid. Help for the current page opens in a new window.\\n\\nOur Online Help is completely integrated with the SysAid Community. We highly recommend you visit there to ask questions, read what other SysAiders have posted, and enrich your knowledge of SysAid.\\nFor further documentation on SysAid's modules, functionality, setup, and more, visit http://www.sysaid.com/documentation.htm.\\n\\nOur support team is always ready and eager to answer any of your questions.  Feel free to contact us at support@sysaid.com or submit a service record at http://helpdesk.sysaid.com/EndUserPortal.jsp.\\n\\nEnjoy SysAid!\\n",
## 				"valueClass": "",
## 				"keyCaption": "Description",
## 				"valueCaption": "This is your first service record in your Service Desk list.\\nNow you can get started with everything SysAid has to offer!\\n\\nFor every page in SysAid, you can access instructions and help relevant for that page.\\nTo access the online help, click your profile name on the top-right corner of the screen and select Online Aid. Help for the current page opens in a new window.\\n\\nOur Online Help is completely integrated with the SysAid Community. We highly recommend you visit there to ask questions, read what other SysAiders have posted, and enrich your knowledge of SysAid.\\nFor further documentation on SysAid's modules, functionality, setup, and more, visit http://www.sysaid.com/documentation.htm.\\n\\nOur support team is always ready and eager to answer any of your questions.  Feel free to contact us at support@sysaid.com or submit a service record at http://helpdesk.sysaid.com/EndUserPortal.jsp.\\n\\nEnjoy SysAid!\\n"
## 			},
## 			{
## 				"key": "insert_time",
## 				"value": 1604599459147,
## 				"valueClass": "",
## 				"keyCaption": "Request time",
## 				"valueCaption": "11/05/2020 01:04:19 PM"
## 			},
## 			{
## 				"key": "title",
## 				"value": "Welcome to SysAid!",
## 				"valueClass": "",
## 				"keyCaption": "Title",
## 				"valueCaption": "Welcome to SysAid!"
## 			},
## 			{
## 				"key": "request_user_name",
## 				"value": null,
## 				"valueClass": "",
## 				"keyCaption": "Request username",
## 				"valueCaption": ""
## 			},
## 			{
## 				"key": "followup_user",
## 				"value": null,
## 				"valueClass": "",
## 				"keyCaption": "Followup User",
## 				"valueCaption": ""
## 			},
## 			{
## 				"key": "workaround",
## 				"value": "",
## 				"valueClass": "",
## 				"keyCaption": "Workaround",
## 				"valueCaption": ""
## 			},
## 			{
## 				"key": "current_support_level",
## 				"value": 0,
## 				"valueClass": "",
## 				"keyCaption": "Current Support Level",
## 				"valueCaption": "0"
## 			},
## 			{
## 				"key": "update_time",
## 				"value": 1604599459173,
## 				"valueClass": "",
## 				"keyCaption": "Modify time",
## 				"valueCaption": "11/05/2020 01:04:19 PM"
## 			},
## 			{
## 				"key": "success_rating",
## 				"value": 0,
## 				"valueClass": "",
## 				"keyCaption": "Success Rating",
## 				"valueCaption": "0"
## 			},
## 			{
## 				"key": "update_user",
## 				"value": null,
## 				"valueClass": "",
## 				"keyCaption": "Modify User",
## 				"valueCaption": ""
## 			},
## 			{
## 				"key": "cust_notes",
## 				"value": "",
## 				"valueClass": "",
## 				"keyCaption": "SR Custom Notes",
## 				"valueCaption": ""
## 			},
## 			{
## 				"key": "followup_text",
## 				"value": "",
## 				"valueClass": "",
## 				"keyCaption": "Followup Text",
## 				"valueCaption": ""
## 			},
## 			{
## 				"key": "email_account",
## 				"value": " ",
## 				"valueClass": "",
## 				"keyCaption": "Email Account",
## 				"valueCaption": " "
## 			},
## 			{
## 				"key": "responsibility",
## 				"value": 1,
## 				"valueClass": "",
## 				"keyCaption": "Assigned to",
## 				"valueCaption": "admin"
## 			},
## 			{
## 				"key": "urgency",
## 				"value": 5,
## 				"valueClass": "",
## 				"keyCaption": "Urgency",
## 				"valueCaption": "Low"
## 			},
## 			{
## 				"key": "request_user",
## 				"value": null,
## 				"valueClass": "",
## 				"keyCaption": "Request user",
## 				"valueCaption": ""
## 			},
## 			{
## 				"key": "sub_type",
## 				"value": 6,
## 				"valueClass": "",
## 				"keyCaption": "Sub Type",
## 				"valueCaption": "DEFAULT"
## 			},
## 			{
## 				"key": "followup_actual_date",
## 				"value": null,
## 				"valueClass": "",
## 				"keyCaption": "Followup Actual Date",
## 				"valueCaption": ""
## 			},
## 			{
## 				"key": "department",
## 				"value": null,
## 				"valueClass": "",
## 				"keyCaption": "Department",
## 				"valueCaption": ""
## 			},
## 			{
## 				"key": "computer_id",
## 				"value": null,
## 				"valueClass": "",
## 				"keyCaption": "Asset ID",
## 				"valueCaption": ""
## 			},
## 			{
## 				"key": "cc",
## 				"value": "",
## 				"valueClass": "",
## 				"keyCaption": "CC",
## 				"valueCaption": ""
## 			},
## 			{
## 				"key": "timer1",
## 				"value": 109637253,
## 				"valueClass": "",
## 				"keyCaption": "Time to Repair",
## 				"valueCaption": "109637253"
## 			},
## 			{
## 				"key": "computer_name",
## 				"value": null,
## 				"valueClass": "",
## 				"keyCaption": "Main Asset",
## 				"valueCaption": ""
## 			},
## 			{
## 				"key": "timer2",
## 				"value": 109637253,
## 				"valueClass": "",
## 				"keyCaption": "Time to Respond",
## 				"valueCaption": "109637253"
## 			},
## 			{
## 				"key": "due_date",
## 				"value": null,
## 				"valueClass": "",
## 				"keyCaption": "Due Date",
## 				"valueCaption": ""
## 			},
## 			{
## 				"key": "cust_text1",
## 				"value": null,
## 				"valueClass": "",
## 				"keyCaption": "SR Custom Text 1",
## 				"valueCaption": ""
## 			},
## 			{
## 				"key": "cust_text2",
## 				"value": null,
## 				"valueClass": "",
## 				"keyCaption": "SR Custom Text 2",
## 				"valueCaption": ""
## 			},
## 			{
## 				"key": "merged_to",
## 				"value": null,
## 				"valueClass": "",
## 				"keyCaption": "Merged to",
## 				"valueCaption": ""
## 			},
## 			{
## 				"key": "account_id",
## 				"value": "free",
## 				"valueClass": "",
## 				"keyCaption": "Account",
## 				"valueCaption": "free"
## 			},
## 			{
## 				"key": "escalation",
## 				"value": 0,
## 				"valueClass": "",
## 				"keyCaption": "Escalation Level",
## 				"valueCaption": "0"
## 			},
## 			{
## 				"key": "change_category",
## 				"value": 0,
## 				"valueClass": "",
## 				"keyCaption": "Classification",
## 				"valueCaption": ""
## 			},
## 			{
## 				"key": "assigned_group",
## 				"value": null,
## 				"valueClass": "",
## 				"keyCaption": "Admin group",
## 				"valueCaption": ""
## 			},
## 			{
## 				"key": "location",
## 				"value": null,
## 				"valueClass": "",
## 				"keyCaption": "Location",
## 				"valueCaption": ""
## 			},
## 			{
## 				"key": "sr_type",
## 				"value": 1,
## 				"valueClass": "",
## 				"keyCaption": "Service Record Type",
## 				"valueCaption": "Incident"
## 			}
## 		]
## 	}
## ]