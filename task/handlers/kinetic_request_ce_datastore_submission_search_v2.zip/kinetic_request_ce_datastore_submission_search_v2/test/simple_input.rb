{
  'info' => {
    'api_server' => 'https://localhost:8080/kinetic',
    'api_username' => 'user@kineticdata.com',
    'api_password' => 'password',
    'space_slug' => 'acme',
    'enable_debug_logging'=>'yes'
  },
  'parameters' => {
    'error_handling' => 'Error Message',
    'space_slug' => '',
    'form_slug' => 'cars',
    'direction' => 'ASC',
    'index' => 'values[Make]',
    'query' => 'values[Make]="Ford"',
    'limit' => '100',
    'page_token' => '',
    'includes' => 'details,values,form',
    'return_type' => 'JSON'
  }
}
