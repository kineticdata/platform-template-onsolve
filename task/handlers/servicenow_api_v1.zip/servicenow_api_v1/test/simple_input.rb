{
  'info' => {
    'api_username' => "kinetic_integration_user",
    'api_password' => "",
    'api_location' => "",
    'enable_debug_logging' => 'true'
  },
  'parameters' => {
    'error_handling' => 'Error Message',
    'method' => 'POST',
    'path' => '/api/now/table/incident',
    'body' => '{"caller_id":"matthew.howe@kineticdata.com","short_description":"Problem with my computer."}'
  }
}
