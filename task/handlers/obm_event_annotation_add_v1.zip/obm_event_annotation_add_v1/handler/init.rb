# Require the dependencies file to load the vendor libraries
require File.expand_path(File.join(File.dirname(__FILE__), 'dependencies'))

class ObmEventAnnotationAddV1
  def initialize(input)
    # Set the input document attribute
    @input_document = REXML::Document.new(input)

    # Store the info values in a Hash of info names to values.
    @info_values = {}
    REXML::XPath.each(@input_document,"/handler/infos/info") { |item|
      @info_values[item.attributes['name']] = item.text.to_s.strip
    }

    @enable_debug_logging = @info_values['enable_debug_logging'] == 'Yes'

    # Store parameters values in a Hash of parameter names to values.
    @parameters = {}
    REXML::XPath.match(@input_document, '/handler/parameters/parameter').each do |node|
      @parameters[node.attribute('name').value] = node.text.to_s
    end
  end


  def execute
    begin
      api_server      = @info_values['api_server']
      api_username    = URI.encode(@info_values["api_username"])
      api_password    = @info_values["api_password"]
      event_id        = @parameters["event_id"]
      #xml            = @parameters["xml"]
      #annotation_xml  = %|<?xml version="1.0" encoding="UTF-8" standalone="yes" ?><annotation xmlns="http://www.hp.com/2009/software/opr/data_model"><author>#{escape(api_username)}</author/><text>#{escape(@parameters['annotation_content'])}</text></annotation>|
      annotation_xml  = %|<annotation xmlns="http://www.hp.com/2009/software/opr/data_model"><author>#{escape(api_username)}</author><text>#{escape(@parameters['annotation_content'])}</text></annotation>|

      puts "Annotation XML: #{annotation_xml}" if @enable_debug_logging

      error_handling  = @parameters["error_handling"]

      puts "Error handling set to #{error_handling}" if @enable_debug_logging

      api_route = "#{api_server}/opr-web/rest/9.10/event_list/#{event_id}/annotation_list"

      puts "API ROUTE: #{api_route}" if @enable_debug_logging

      resource = RestClient::Resource.new(api_route, { :user => api_username, :password => api_password })

      response = resource.get

      cookies = response.headers['set_cookie'.to_sym]

      headers = Hash.new
      headers['Content-Type'.to_sym] = 'application/xml'
      headers[:cookie] = ''
      cookies.each do |ele|
        ele.split(';').each do |ele|
          arr = ele.split("=")
          if (arr.size() > 1)
            if (arr[0] == 'JSESSIONID')
              headers[:JSESSIONID] = arr[1]
              headers[:cookie] = headers[:cookie] + " JSESSIONID=#{arr[1]};"
            elsif (arr[0] == 'LWSSO_COOKIE_KEY')
              headers[:LWSSO_COOKIE_KEY] = arr[1]
              headers[:cookie] = headers[:cookie] + " LWSSO_COOKIE_KEY=#{arr[1]};"
            elsif (arr[0] == 'secureModifyToken')
              headers['X-Secure-Modify-Token'.to_sym] = arr[1]
              headers[:cookie] = headers[:cookie] + " secureModifyToken=#{arr[1]};"
            end
          end
        end
      end

      resource = RestClient::Resource.new(api_route, { :user => api_username, :password => api_password })

      #response = resource.put(xml, headers)
      response = resource.post(annotation_xml, headers)

    rescue RestClient::Exception => error
      error_message = JSON.parse(error.response)["error"]
      if error_handling == "Raise Error"
        raise error_message
      end
    rescue StandardError => error
      error_message = error.message
      if error_handling == "Raise Error"
        raise error_message
      end
    end

    # Build the results XML
    <<-RESULTS
    <results>
      <result name="Handler Error Message">#{escape(error_message)}</result>
      <result name="EventXml">#{escape(response)}</result>
    </results>
    RESULTS

  end

  # This is a template method that is used to escape results values (returned in
  # execute) that would cause the XML to be invalid.  This method is not
  # necessary if values do not contain character that have special meaning in
  # XML (&, ", <, and >), however it is a good practice to use it for all return
  # variable results in case the value could include one of those characters in
  # the future.  This method can be copied and reused between handlers.
  def escape(string)
    # Globally replace characters based on the ESCAPE_CHARACTERS constant
    string.to_s.gsub(/[&"><]/) { |special| ESCAPE_CHARACTERS[special] } if string
  end
  # This is a ruby constant that is used by the escape method
  ESCAPE_CHARACTERS = {'&'=>'&amp;', '>'=>'&gt;', '<'=>'&lt;', '"' => '&quot;'}

end
