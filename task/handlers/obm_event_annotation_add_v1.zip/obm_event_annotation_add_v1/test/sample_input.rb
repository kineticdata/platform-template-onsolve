{
  'info' => {
    'api_server'            => 'https://obm.kineticdata.com',
    'api_username'          => 'admin',
    'api_password'          => 'password',
    'enable_debug_logging'  => 'Yes'
  },
  'parameters' => {
    'event_id'           => 'a0c07423-3966-487b-a507-f6a7e5063735',
    'annotation_content' => 'This is an annotation.',
    'error_handling'     => 'Raise Error'
  }
}
