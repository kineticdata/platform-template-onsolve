{
  'info' => {
    'api_username' => "",
    'api_password' => "",
    'api_location' => "",
    'enable_debug_logging' => 'true'
  },
  'parameters' => {
    'error_handling' => 'Error Message',
    'trigger_input_json' => '["6afbe308837622ee93a1f232b74ccbaea2919f5c"]',
  }
}
