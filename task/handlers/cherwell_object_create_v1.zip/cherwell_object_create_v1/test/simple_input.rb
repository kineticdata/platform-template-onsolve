{
  'info' => {
    'api_location' => '',
    'client_id' => '',
    'client_secret' => '',
    'username' => '',
    'password' => '',
    'auth_mode' => '',
    'enable_debug_logging'=>'yes'
  },
  'parameters' => {
      'error_handling' => 'Error Message',
      'object_name' => 'Incident',
    'object_json' => '{"Status":"New","Description":"From Kinetic Task Handler using the REST API","Short Description":"New Incident","Priority":"3","Incident Type":"Incident","Service":"Applications","Category":"Application","Subcategory":"Submit Incident","Customer ID":"93f8fdd0d46af52b97527a48c8938074801cee9bf5","UMMS - Site":"Columbia Data Center","UMMS - Other Location":""}',
    'object_matt' => 'input here'
  }
}
