{
  'info' => {
    'server' => '',
    'username' => '',
    'password' => '',
    'port' => '',
    'prognum' => '',
    'authentication' => '',
    'enable_debug_logging' => 'Yes',
    'disable_caching' => 'No'
  },
  'parameters' => {
    'error_handling' => 'Error Message',
	  'form' => 'CTM:People',
    'query' => %|'Remedy Login ID' = "username"|
  }
}
