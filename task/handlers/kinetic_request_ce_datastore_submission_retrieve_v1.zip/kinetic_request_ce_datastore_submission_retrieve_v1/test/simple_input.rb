{
  'info' => {
    'api_server' => 'https://localhost:8080/kinetic',
    'api_username' => 'user@kineticdata.com',
    'api_password' => 'password',
    'space_slug' => 'acme',
    'enable_debug_logging'=>'yes'
  },
  'parameters' => {
    'error_handling' => 'Raise Error',
    'space_slug' => '',
    'retrieve_by' => 'Id',
    'form_slug' => '',
    'index' => '',
    'query' => '',
    'submission_id' => '29f141f3-f00c-11e7-9a71-0506559f5412'
  }
}
