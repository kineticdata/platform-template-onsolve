{
  'info' => {
    'server' => '',
    'username' => '',
    'password' => '',
    'port' => '',
    'prognum' => '',
    'authentication' => '',
    'enable_debug_logging' => 'Yes'
  },
  'parameters' => {
    'error_handling' => 'Error Message',
    'form' => '',
    'request_id' => '',
    'field_values' => ''
  }
}
