{
  'info' => {
    'server' => '',
    'username' => '',
    'password' => '',
    'port' => '',
    'prognum' => '',
    'authentication' => '',
    'enable_debug_logging' => 'Yes'
  },
  'parameters' => {
	'form' => 'HPD:Help Desk',
  'request_id' => 'INC000000002012',
	'field_values' => '{"Assignee Login ID":"matthew.howe@kineticdata.com","Assignee":"Matt Howe"}'
  }
}
