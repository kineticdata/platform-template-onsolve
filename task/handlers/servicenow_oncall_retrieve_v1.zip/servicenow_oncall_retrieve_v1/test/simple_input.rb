{
  'info' =>
  {
    'username'=>'',
    'password'=>'',
    'server'=>'',
    'enable_debug_logging'=>'yes'
  },
  'parameters' =>
  {
    'error_handling' => 'Error Message',
    'api_route' => 'whoisoncall',
    'api_parameters' => 'group_ids=123456'
  }
}
