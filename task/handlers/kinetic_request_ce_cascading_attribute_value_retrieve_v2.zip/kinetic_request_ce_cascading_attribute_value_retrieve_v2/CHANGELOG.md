Kinetic Request CE Cascading Attribute Value Retrieve V2.1 (2018-05-25)
* API Server Info Value changed to allow ${space} in the url for subdomain support
(ie. https://${space}.localhost:8080/kinetic)

Kinetic Request CE Cascading Attribute Value Retrieve V2 (2017-08-18)
* Removed menus from start and end contexts to allow values to be passed in as variables (from
routine input)

Kinetic Request CE Cascading Attribute Value Retrieve V1 (2017-02-18)
* Initial version.  See README for details.