{
  'info' => {
    'server' => '',
    'username' => '',
    'password' => '',
    'port' => '',
    'prognum' => '',
    'authentication' => '',
    'enable_debug_logging' => 'Yes'
  },
  'parameters' => {
    'error_handling' => 'Error Message',
    'form' => 'User',
    'request_id' => '000000000000001'
  }
}
