{
  'info' => {
    'api_username' => "username",
    'api_password' => "password",
    'api_location' => "https://server.com/app",
    'enable_debug_logging' => 'true'
  },
  'parameters' => {
    'error_handling' => 'Error Message',
    'method' => 'POST',
    'path' => '/webApis/test-webapi',
    'body' => '{"label_1":"value_1", "label_2":value_2"}'
  }
}
