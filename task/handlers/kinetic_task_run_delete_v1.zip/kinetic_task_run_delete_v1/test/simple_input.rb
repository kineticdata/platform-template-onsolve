{
  'info' =>
  {
    'username' => '',
    'password' => '',
    'kinetic_task_location' => 'http://server:port/kinetic-task',
    'signature_key' => nil,
    'signature_secret' => nil,
    'enable_debug_logging' => 'Yes'
  },
  'parameters' =>
  {
    'run_id' => '115591',
    'signature_key' => nil,
    'signature_secret' => nil
  }
}
