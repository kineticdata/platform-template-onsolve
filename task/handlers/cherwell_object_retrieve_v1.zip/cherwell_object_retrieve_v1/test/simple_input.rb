{
  'info' => {
    'api_location' => 'http://cherwell.kineticdata.com/CherwellAPI',
    'client_id' => '7a13da8a-6600-4274-a0a0-817313e2c65e',
    'client_secret' => '',
    'username' => 'kinetic-integration-user',
    'password' => 'xgQAWL2ZGzVJrskqVfowgYpH',
    'enable_debug_logging'=>'yes'
  },
  'parameters' => {
    'error_handling' => 'Error Message',
    'object_name' => 'Incident',
    'object_id' => ''
  }
}
