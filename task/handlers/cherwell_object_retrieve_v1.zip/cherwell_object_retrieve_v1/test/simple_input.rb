{
  'info' => {
    'api_location' => '',
    'client_id' => '',
    'client_secret' => '',
    'username' => '',
    'password' => '',
    'enable_debug_logging'=>'yes'
  },
  'parameters' => {
    'object_name' => 'Incident',
    'object_id' => ''
  }
}
